function searchItem(event) {
    event.preventDefault();
    var searchTerm = document.getElementById("search-input").value.toLowerCase();
    
   
    switch (searchTerm) {
        case "iphone 12":
            scrollToItem("#iphone12");
            break;
        case "s21":
            scrollToItem("#s21");
            break;
        case "s23":
            scrollToItem("#s23");
            break;
        case "iphone 14":
            scrollToItem("#iphone14");
            break;
        case "iphone 13":
            scrollToItem("#iphone13");
            break;
        default:
            alert("Item not found!");
    }
}


function scrollToItem(item) {
    var element = document.querySelector(item);
    if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
        alert("Item not found!");
    }
}


document.getElementById("searchform").addEventListener("submit", searchItem);

