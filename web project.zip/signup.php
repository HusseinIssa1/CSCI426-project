<?php
session_start();
include("db.php");
if($_SERVER['REQUEST_METHOD']=="POST")
{

$firstname = $_POST['fname'];
$lasttname = $_POST['lname'];
$Gender = $_POST['gender'];
$Dateofbirth = $_POST['dof'];
$id = $_POST['name'];
$gmail = $_POST['email'];
$password = $_POST['password'];
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

if(!empty($gmail)&& !empty($password)&& !is_numeric($gmail))
{
    $query = "insert into user(Name, LastName, Gender, DateOfBirth, ID, email, Password) values ('$firstname','$lasttname','$Gender','$Dateofbirth','$id','$gmail','$password ')";
    mysqli_query($con,  $query);
    echo "<script type='text/javascript'> alert('Successfully Registered')</script>";
}
else{
    echo"<script type='text/javascript'> alert('please Enter valid information')</script>"; 
}

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
            border-radius: 4px;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group:last-child {
            margin-bottom: 0;
        }

        h2 {
            text-align: center;
        }
    </style>
</head>
<body>
    <form action="#" method="POST">
     
        <div class="form-group">
            <label for="name">ID:</label>
            <input type="number" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" id="fname" name="fname" required>
        </div>
        <div class="form-group">
            <label for="name">LastName:</label>
            <input type="text" id="fname" name="lname" required>
        </div>
        <div class="form-group">
            <label for="name">Gender:</label>
            <input type="text" id="gender" name="gender" required>
        </div>
        <div class="form-group">
            <label for="name">Date OF Birth:</label>
            <input type="date" id="dof" name="dof" required>
        </div>
        
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="text" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <input type="submit" value="Sign Up">
    </form>
</body>
</html>