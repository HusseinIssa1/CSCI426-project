<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "signup";

$con = new mysqli($servername, $username, $password, $dbname,3307);

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}
?>